<?php
include 'connect.php';
if(isset($_POST['submit'])){
    $ID = $_POST['aID'];
    $month = $_POST['aMonth'];
    // $OH = $_POST['aOH'];
    // $NO_Presents = $_POST['aNO_Presents'];

    $sql = "insert into `attendance` (aID,aMonth,aOH,aNO_Presents) values ('$ID','$month',0,0)";
    $result = mysqli_query($con,$sql);
    if($result){
        //echo "Data inserted";
        header('location:display_attendance.php');
    }else{
        die(mysqli_error($con));
    }
}
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.rtl.min.css" >
    <link rel="stylesheet" href="user_styles.css" >
    <title>Add Month</title>
  </head>
  <body>
    
    <div class="container my-5">
    <button class = "btn btn-primary my-5"><a href="display_attendance.php" class = "text-light">Cancel</a>
    </button>

    <form method = "post">
  <div class="mb-3">
    <label>ID</label>
    <input type="number" class="form-control" placeholder = "Enter ID" name = "aID" autocomplete = "off">
  </div>
  <div class="mb-3">
    <label>Month</label>
    <input type="text" class="form-control" placeholder = "Enter Month" name = "aMonth" autocomplete = "off">
  </div>
  <!-- <div class="mb-3">
    <label>Overtime Hours</label>
    <input type="number" class="form-control" placeholder = "Enter number of overtime hours" name = "aOH" autocomplete = "off">
  </div>
  <div class="mb-3">
    <label>No. of Presents</label>
    <input type="number" class="form-control" placeholder = "Enter number of presents" name = "aNO_Presents" autocomplete = "off">
  </div> -->

  
  <button type="submit" class="btn btn-primary" name = "submit">Add</button>
</form>

    </div>

  </body>
</html>
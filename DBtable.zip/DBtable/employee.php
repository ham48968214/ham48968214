<?php
include 'connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Info</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.rtl.min.css" >
    <link rel="stylesheet" href="user_styles.css" >
    <link rel="stylesheet" href="table.css" >
</head>
<body>

    <div class="container">
        <button class = "btn btn-primary my-5"><a href="deleteLogin.php" class = "text-light">Logout</a>
        </button>

        <table class="table">
  <!-- <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Username</th>
      <th scope="col">Password</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">CNIC</th>
      <th scope="col">Date_of_Birth</th>
      <th scope="col">Employee_Type</th>
      <th scope="col">Department</th>
      <th scope="col">Package_Type</th>
      <th scope="col">Salary</th>
      <th scope="col">Credit_Hours</th>
      <th scope="col">Tax</th>
    </tr>
  </thead> -->
  <tbody>

    <?php
        $sql = "Select * from employee as e, login as l WHERE e.eUsername = l.lUsername and e.ePassword = l.lPassword";
        $result = mysqli_query($con,$sql);
        $sql2 = "select * from attendance where aID in (select eID from employee as e, login as l WHERE e.eUsername = l.lUsername and e.ePassword = l.lPassword)";
        $result2 = mysqli_query($con,$sql2);
        
        if(mysqli_num_rows($result) === 1){
            while($row = mysqli_fetch_assoc($result)){
                $name = $row['eName'];
                $ID = $row['eID'];
                $username = $row['eUsername'];
                $password = $row['ePassword'];
                $CNIC = $row['eCNIC'];
                $salary = $row['eSalary'];
                $DOB = $row['eDOB'];
                $Employee_Type=$row['eType'];
                $Department=$row['eDept'];
                $CreditHours = $row['eTCH'];
                $PackageType=$row['ePackage'];
                $Tax=$row['eTax'];
                $Email = $row['eEmail'];

                echo '<tr><th>ID</th><td>'.$ID.'</td></tr>';
                echo '<tr><th>Username</th><td>'.$username.'</td></tr>';
                echo '<tr><th>Password</th><td>'.$password.'</td></tr>';
                echo '<tr><th>Name</th><td>'.$name.'</td></tr>';
                echo '<tr><th>Email</th><td>'.$Email.'</td></tr>';
                echo '<tr><th>CNIC</th><td>'.$CNIC.'</td></tr>';
                echo '<tr><th>Date_Of_Birth</th><td>'.$DOB.'</td></tr>';
                echo '<tr><th>Employee_Type</th><td>'.$Employee_Type.'</td></tr>';
                echo '<tr><th>Department</th><td>'.$Department.'</td></tr>';
                echo '<tr><th>Package_Type</th><td>'.$PackageType.'</td></tr>';
                echo '<tr><th>Basic_Salary</th><td>'.$salary.'</td></tr>';
                echo '<tr><th>Credit_Hours</th><td>'.$CreditHours.'</td></tr>';
                echo '<tr><th>Tax</th><td>'.$Tax.'</td></tr>';

               echo'<footer></footer>';

              echo 
              '<tr>
                <th scope="col">Month</th>
                <th scope="col">Overtime_Hours</th>
                <th scope="col">Number_of_Presents</th>
                <th scope="col">Total_Salary</th>
              </tr>';

              if($result2){
                while($row = mysqli_fetch_assoc($result2)){
                    $month = $row['aMonth'];
                    $OH = $row['aOH'];
                    $NO_Presents = $row['aNO_Presents'];
                    $total_salary = $row['total_salary'];
                    echo '<tr>
                    <th scope="row">'.$month.'</div></th>
                    <td>'.$OH.'</td>
                    <td>'.$NO_Presents.'</td>
                    <td>'.$total_salary.'</td>
                  </tr>';
                }
            }
            }
        }
        else {
           
            header('location:deleteLogin.php');
        }

    ?>

  </tbody>
</table>


    </div>
    
</body>
</html>
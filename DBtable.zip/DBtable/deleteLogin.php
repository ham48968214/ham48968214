<?php

include 'connect.php';
//if(isset($_GET['deleteid'])){
  //  $id = $_GET['deleteid'];

    $sql = "delete from `login` ";
    $result = mysqli_query($con,$sql);

    if($result){
        // echo "Deleted Succesfully";
        header('location:login2.php');
    }else{
        die(mysqli_error($con));
    }
//}

?>
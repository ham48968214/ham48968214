<?php
include 'connect.php';
if(isset($_POST['submit'])){
    $name = $_POST['eName'];
    $ID = $_POST['eID'];
    $username = $_POST['eUsername'];
    $password = $_POST['ePassword'];
    $CNIC = $_POST['eCNIC'];
    $salary = $_POST['eSalary'];
    $DOB = $_POST['eDOB'];
    $Employee_Type=$_POST['eType'];
    $Department=$_POST['eDept'];
    $CreditHours = $_POST['eTCH'];
    $Package_Type = $_POST['ePackage'];
    $Tax = $_POST['eTax'];
    $Email = $_POST['eEmail'];

    $Month = $_POST['aMonth'];

    $sql = "insert into `employee` (eID,eUsername,ePassword,eName,eEmail,eCNIC,eSalary,eDOB,eType,eDept,eTCH,ePackage,eTax) values ('$ID','$username','$password','$name','$Email','$CNIC','$salary','$DOB','$Employee_Type','$Department','$CreditHours','$Package_Type','$Tax')";
    $result = mysqli_query($con,$sql);
    $sql2 = "update `department` SET dEmps = dEmps+1 WHERE dNO = $Department";
    $result2 = mysqli_query($con,$sql2);
    $sql3 = "insert into `attendance` (aID,aMonth,aOH,aNO_Presents) values ('$ID','$Month',0,0)";
    $result3 = mysqli_query($con,$sql3);
    if($result){
        //echo "Data inserted";
        header('location:display.php');
    }else{
        die(mysqli_error($con));
    }
}
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.rtl.min.css" >
    <link rel="stylesheet" href="user_styles.css" >
    <title>Add User</title>
  </head>
  <body>
    
    <div class="container my-5">
    <button class = "btn btn-primary my-5"><a href="display.php" class = "text-light">Cancel</a>
    </button>

    <form method = "post">
  <div class="mb-3">
    <label>ID</label>
    <input type="number" class="form-control" placeholder = "Enter your ID" name = "eID" autocomplete = "off">
  </div>
  <div class="mb-3">
    <label>Username</label>
    <input type="text" class="form-control" placeholder = "Enter your Username" name = "eUsername" autocomplete = "off">
  </div>
  <div class="mb-3">
    <label>Password</label>
    <input type="text" class="form-control" placeholder = "Enter your password" name = "ePassword" autocomplete = "off">
  </div>
  <div class="mb-3">
    <label>Name</label>
    <input type="text" class="form-control" placeholder = "Enter your name" name = "eName" autocomplete = "off">
  </div>
  <div class="mb-3">
    <label>Email</label>
    <input type="email" class="form-control" placeholder = "Enter your email" name = "eEmail" autocomplete = "off">
  </div>
  <div class="mb-3">
    <label>CNIC</label>
    <input type="number" class="form-control" placeholder = "Enter your CNIC" name = "eCNIC" autocomplete = "off">
  </div>
  <div class="mb-3">
    <label>DOB</label>
    <input type="text" class="form-control" placeholder = "Enter your Date Of Birth" name = "eDOB" autocomplete = "off">
  </div>
  <div class="mb-3">
    <label>Employee_Type</label>
    <input type="text" class="form-control" placeholder = "Enter your Employee Type " name = "eType" autocomplete = "off">
  </div>
  <div class="mb-3">
    <label>Salary</label>
    <input type="number" class="form-control" placeholder = "Enter your salary" name = "eSalary" autocomplete = "off">
  </div>
  <div class="mb-3">
    <label>Package_Type</label>
    <input type="text" class="form-control" placeholder = "Enter your Package Type" name = "ePackage" autocomplete = "off">
  </div>
  <div class="mb-3">
    <label>Department</label>
    <input type="number" class="form-control" placeholder = "Enter your Department number" name = "eDept" autocomplete = "off">
  </div>
  <div class="mb-3">
    <label>CreditHours</label>
    <input type="number" class="form-control" placeholder = "Total Credit Hours" name = "eTCH" autocomplete = "off">
  </div>
  <div class="mb-3">
    <label>Tax</label>
    <input type="number" class="form-control" placeholder = "Tax Applicable" name = "eTax" autocomplete = "off">
  </div>
  <div class="mb-3">
    <label>Month</label>
    <input type="text" class="form-control" placeholder = "Enter Month of hiring" name = "aMonth" autocomplete = "off">
  </div>
  
  <button type="submit" class="btn btn-primary" name = "submit">Submit</button>
</form>

    </div>

  </body>
</html>
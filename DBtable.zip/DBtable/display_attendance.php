<?php
include 'connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Table</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.rtl.min.css" >
    <link rel="stylesheet" href="user_styles.css" >
</head>
<body>

    <div class="container">
        <button class = "btn btn-primary my-5"><a href="attendance.php" class = "text-light">Add Month</a>
        </button>
        <button class = "btn btn-primary my-5"><a href="Admin.html" class = "text-light">Main Menu</a>
        </button>

        <table class="table">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Month</th>
      <th scope="col">Overtime Hours</th>
      <th scope="col">No. of Presents</th>
      <th scope="col">Total_Salary</th>
      <th scope="col">Operations</th>
    </tr>
  </thead>
  <tbody>

    <?php

        $sql = "Select * from `attendance`";
        $result = mysqli_query($con,$sql);
        if($result){
            while($row = mysqli_fetch_assoc($result)){
                $ID = $row['aID'];
                $month = $row['aMonth'];
                $OH = $row['aOH'];
                $NO_Presents = $row['aNO_Presents'];
                $total_salary = $row['total_salary'];
                echo '<tr>
                <th scope="row">'.$ID.'</div></th>
                <td>'.$month.'</td>
                <td>'.$OH.'</td>
                <td>'.$NO_Presents.'</td>
                <td>'.$total_salary.'</td>
                <td>
                    <button class = "btn btn-primary"><a href="update_Attendance.php?updateid='.$ID.'" class = "text-light">Update</a></button>
                </td>
              </tr>';
            }
        }

    ?>

  </tbody>
</table>


    </div>
    
</body>
</html>
<?php
include 'connect.php';
if(isset($_POST['log'])){

    $user = $_POST['lUsername'];
    $pass = $_POST['lPassword'];

    if($user === "accountant.giki" and $pass === "giki"){
        header('location:Admin.html');
    }else{
        $sql = "insert into `login` (lUsername,lPassword) values ('$user','$pass')";
        $result = mysqli_query($con,$sql);
        if($result){
            //echo "Data inserted";
            header('location:employee.php');
        }else{
            die(mysqli_error($con));
        }
    }
}
?>

<!DOCTYPE html>    
<html>    
<head>    
    <title>Login</title>    
    <link rel="stylesheet" href="LOGIN.css">    
</head>    
<body>

    <nav>
        <a href="Home.html">Home</a>
        <a href="Contact.html">Contact Us</a>
    </nav>

    <h2>Login Page</h2>
       
    <div class="login">    
    <form method = "post"> 
    <div class="imgcontainer">
        <img src="images/BlankImage.jpg" alt="Avatar" class="avatar">
    </div>  
    <div class="mb-3">
        <label><b>Username</b></label>
        <input type="text" class="form-control" name = "lUsername" required autocomplete = "off">
    </div>
    <br><br> 
    <div class="mb-3">
        <label><b>Password</b></label>
        <input type="text" class="form-control" name = "lPassword" requireds autocomplete = "off">
    </div> 
    <br><br> 
    <button type="submit" class="btn btn-danger" name = "log">Login</button>   
        <!-- <input type="checkbox" id="check">    
        <span>Remember me</span>    
        <br><br>    
        Forgot <a href="#">Password</a>     -->
    </form>     
</div>    
</body>    
</html>   
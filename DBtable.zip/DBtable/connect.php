<?php

$con = new mysqli('localhost','root','','Payroll');

if(!$con){
    die(mysqli_error($con));
}

?>
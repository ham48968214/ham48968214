<?php
include 'connect.php';
$id = $_GET['updateid'];
$sql = "select * from `employee` where eID = $id";
$result = mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);
    $name = $row['eName'];
    $ID = $row['eID'];
    $username = $row['eUsername'];
    $password = $row['ePassword'];
    $CNIC = $row['eCNIC'];
    $salary = $row['eSalary'];
    $DOB = $row['eDOB'];
    $Employee_Type=$row['eType'];
    $Department=$row['eDept'];
    $CreditHours = $row['eTCH'];
    $Package_Type = $row['ePackage'];
    $Tax = $row['eTax'];
    $Email = $row['eEmail'];

if(isset($_POST['submit'])){
    $name = $_POST['eName'];
    $ID = $_POST['eID'];
    $username = $_POST['eUsername'];
    $password = $_POST['ePassword'];
    $CNIC = $_POST['eCNIC'];
    $salary = $_POST['eSalary'];
    $DOB = $_POST['eDOB'];
    $Employee_Type=$_POST['eType'];
    $Department=$_POST['eDept'];
    $CreditHours = $_POST['eTCH'];
    $Package_Type = $_POST['ePackage'];
    $Tax = $_POST['eTax'];
    $Email = $_POST['eEmail'];

    $sql = "update `employee` set eID = $ID, eUsername = '$username', ePassword = '$password', eName = '$name', eCNIC = '$CNIC', eSalary = '$salary', eDOB = '$DOB', eType = '$Employee_Type', eDept = '$Department', eTCH = '$CreditHours', ePackage = '$Package_Type', eTax = '$Tax', eEmail = '$Email' where eID = $ID";
    $result = mysqli_query($con,$sql);
    if($result){
        // echo "Data updated";
        header('location:display.php');
    }else{
        die(mysqli_error($con));
    }
}
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.rtl.min.css" >
    <link rel="stylesheet" href="user_styles.css" >
    <title>User Info Update</title>
  </head>
  <body>
    
    <div class="container my-5">

    <form method = "post">
    <div class="mb-3">
    <label>ID</label>
    <input type="number" class="form-control" placeholder = "Enter your ID" name = "eID" autocomplete = "off" value = <?php echo $ID?>>
  </div>
  <div class="mb-3">
    <label>Username</label>
    <input type="text" class="form-control" placeholder = "Enter your Username" name = "eUsername" autocomplete = "off" value = <?php echo $username?>>
  </div>
  <div class="mb-3">
    <label>Password</label>
    <input type="text" class="form-control" placeholder = "Enter your password" name = "ePassword" autocomplete = "off" value = <?php echo $password?>>
  </div>
  <div class="mb-3">
    <label>Name</label>
    <input type="text" class="form-control" placeholder = "Enter your name" name = "eName" autocomplete = "off" value = <?php echo $name?>>
  </div>
  <div class="mb-3">
    <label>Email</label>
    <input type="email" class="form-control" placeholder = "Enter your email" name = "eEmail" autocomplete = "off" value = <?php echo $Email?>>
  </div>
  <div class="mb-3">
    <label>CNIC</label>
    <input type="number" class="form-control" placeholder = "Enter your CNIC" name = "eCNIC" autocomplete = "off"  value = <?php echo $CNIC?>>
  </div>
  <div class="mb-3">
    <label>Salary</label>
    <input type="number" class="form-control" placeholder = "Enter your salary" name = "eSalary" autocomplete = "off" value = <?php echo $salary?>>
  </div>
  <div class="mb-3">
    <label>DOB</label>
    <input type="text" class="form-control" placeholder = "Enter your Date Of Birth" name = "eDOB" autocomplete = "off"  value = <?php echo $DOB?>>
  </div>
  <div class="mb-3">
    <label>Employee_Type</label>
    <input type="text" class="form-control" placeholder = "Enter your Employee Type " name = "eType" autocomplete = "off" value = <?php echo $Employee_Type?>>
  </div>
  <div class="mb-3">
    <label>Department</label>
    <input type="number" class="form-control" placeholder = "Enter your Department " name = "eDept" autocomplete = "off" value = <?php echo $Department?>>
  </div>
  <div class="mb-3">
    <label>Package_Type</label>
    <input type="text" class="form-control" placeholder = "Enter your Package Type" name = "ePackage" autocomplete = "off" value = <?php echo $Package_Type?>>
  </div>
  <div class="mb-3">
    <label>CreditHours</label>
    <input type="number" class="form-control" placeholder = "Total Credit Hours" name = "eTCH" autocomplete = "off" value = <?php echo $CreditHours?>>
  </div>
  <div class="mb-3">
    <label>Tax</label>
    <input type="number" class="form-control" placeholder = "Tax Applicable" name = "eTax" autocomplete = "off" value = <?php echo $Tax?>>
  </div>


  
  <button type="submit" class="btn btn-primary" name = "submit">Update</button>
</form>

    </div>

  </body>
</html>
<?php
include 'connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Table</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.rtl.min.css" >
    <link rel="stylesheet" href="user_styles.css" >
    <link rel="stylesheet" href="table.css" >
</head>
<body>

    <div class="container">
        <button class = "btn btn-primary my-5"><a href="user.php" class = "text-light">Add User</a>
        </button>
        <button class = "btn btn-primary my-5"><a href="Admin.html" class = "text-light">Main Menu</a>
        </button>

        <table class="table">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Username</th>
      <th scope="col">Password</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">CNIC</th>
      <th scope="col">Date_of_Birth</th>
      <th scope="col">Employee_Type</th>
      <th scope="col">Department</th>
      <th scope="col">Package_Type</th>
      <th scope="col">Salary</th>
      <th scope="col">Credit_Hours</th>
      <th scope="col">Tax</th>
      <th scope="col">Operations</th>
    </tr>
  </thead>
  <tbody>

    <?php

        $sql = "Select * from `employee` order by eDept asc";
        $result = mysqli_query($con,$sql);
        if($result){
            while($row = mysqli_fetch_assoc($result)){
                $name = $row['eName'];
                $ID = $row['eID'];
                $username = $row['eUsername'];
                $password = $row['ePassword'];
                $CNIC = $row['eCNIC'];
                $salary = $row['eSalary'];
                $DOB = $row['eDOB'];
                $Employee_Type=$row['eType'];
                $Department=$row['eDept'];
                $CreditHours = $row['eTCH'];
                $PackageType=$row['ePackage'];
                $Tax=$row['eTax'];
                $Email = $row['eEmail'];
                echo '<tr>
                <th scope="row">'.$ID.'</div></th>
                <td>'.$username.'</td>
                <td>'.$password.'</td>
                <td>'.$name.'</td>
                <td>'.$Email.'</td>
                <td>'.$CNIC.'</td>
                <td>'.$DOB.'</td>
                <td>'.$Employee_Type.'</td>
                <td>'.$Department.'</td>
                <td>'.$PackageType.'</td>
                <td>'.$salary.'</td>
                <td>'.$CreditHours.'</td>
                <td>'.$Tax.'</td>
                <td>
                    <button class = "btn btn-primary mx-5"><a href="update.php?updateid='.$ID.'" class = "text-light">Update</a></button>
                    <button class = "btn btn-danger"><a href="delete.php?deleteid='.$ID.'" class = "text-light">Delete</a></button>
                </td>
              </tr>';
            }
        }

    ?>

  </tbody>
</table>


    </div>
    
</body>
</html>
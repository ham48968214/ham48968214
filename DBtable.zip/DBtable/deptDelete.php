<?php

include 'connect.php';
if(isset($_GET['deleteid'])){
    $deptNO = $_GET['deleteid'];

    $sql = "delete from `department` where dNO = $deptNO";
    $result = mysqli_query($con,$sql);

    if($result){
        // echo "Deleted Succesfully";
        header('location:deptDisplay.php');
    }else{
        die(mysqli_error($con));
    }
}

?>
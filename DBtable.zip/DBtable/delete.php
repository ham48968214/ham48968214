<?php

include 'connect.php';
if(isset($_GET['deleteid'])){
    $id = $_GET['deleteid'];
    $sql2 = "select eDept from employee where eID = $id";
    $result2 = mysqli_query($con,$sql2);
    $row = mysqli_fetch_assoc($result2);
    $deptNO = $row['eDept'];

    $sql = "delete from `employee` where eID = $id";
    $result = mysqli_query($con,$sql);
    $sql2 = "update `department` SET dEmps = dEmps-1 WHERE dNO = $deptNO";
    $result2 = mysqli_query($con,$sql2);
    $sql3 = "delete from `attendance` where aID = $id";
    $result3 = mysqli_query($con,$sql3);

    if($result){
        // echo "Deleted Succesfully";
        header('location:display.php');
    }else{
        die(mysqli_error($con));
    }
}

?>
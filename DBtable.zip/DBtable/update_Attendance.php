<?php
include 'connect.php';
$ID = $_GET['updateid'];
$sql = "select * from `attendance` where aID = $ID";
$result = mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);
$ID = $row['aID'];
$NO_Presents = $row['aNO_Presents'];
$OH = $row['aOH'];
$month = $row['aMonth'];

if(isset($_POST['submit'])){
    
    $NO_Presents = $_POST['aNO_Presents'];
    $OH = $_POST['aOH'];
    

    $sql = "update `attendance` set  aOH = '$OH', aNO_Presents = $NO_Presents, total_salary = $NO_Presents*(SELECT eSalary from employee where eID = $ID) where aID = $ID";
    $result = mysqli_query($con,$sql);
    if($result){
        // echo "Data updated";
        header('location:display_attendance.php');
    }else{
        die(mysqli_error($con));
    }
}
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.rtl.min.css" >
    <link rel="stylesheet" href="user_styles.css" >
    <title>Update Attendance</title>
  </head>
  <body>
    
    <div class="container my-5">
    <button class = "btn btn-primary my-5"><a href="display_attendance.php" class = "text-light">Cancel</a>
    </button>

    <form method = "post">
    <div class="mb-3">
    
  <div class="mb-3">
    <label>Overtime Hour(s)</label>
    <input type="number" class="form-control" placeholder = "Overtime Hours" name = "aOH" autocomplete = "off" value = <?php echo $OH;?>>
  </div>
  <div class="mb-3">
    <label>Number of Presents</label>
    <input type="number" class="form-control" placeholder = "Number of Presents" name = "aNO_Presents" autocomplete = "off" value = <?php echo $NO_Presents;?>>
  </div>
  
  
  <button type="submit" class="btn btn-primary" name = "submit">Update</button>
</form>

    </div>

  </body>
</html>
<?php
include 'connect.php';
if(isset($_POST['submit'])){
    $ID = $_POST['lID'];
    $username = $_POST['lUsername'];
    $password = $_POST['lPassword'];

    $sql = "insert into `login` (lID,lUsername,lPassword) values ('$ID','$username','$password')";
    $result = mysqli_query($con,$sql);
    if($result){
        //echo "Data inserted";
        header('location:displayLogin.php');
    }else{
        die(mysqli_error($con));
    }
}
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.rtl.min.css" >
    <link rel="stylesheet" href="user_styles.css" >
    <title>Login Info</title>
  </head>
  <body>
    
    <div class="container my-5">
    <button class = "btn btn-primary my-5"><a href="displayLogin.php" class = "text-light">Cancel</a>
    </button>

    <form method = "post">
  <div class="mb-3">
    <label>ID</label>
    <input type="number" class="form-control" placeholder = "Enter your ID" name = "lID" autocomplete = "off">
  </div>
  <div class="mb-3">
    <label>Username</label>
    <input type="text" class="form-control" placeholder = "Enter your Username" name = "lUsername" autocomplete = "off">
  </div>
  <div class="mb-3">
    <label>Password</label>
    <input type="text" class="form-control" placeholder = "Enter your password" name = "lPassword" autocomplete = "off">
  </div>
 
  <button class = "btn btn-primary my-5"><a href="displayLogin.php" class = "text-light">Submit</a>
    </button>
</form>

    </div>

  </body>
</html>
<?php
include 'connect.php';
$NO = $_GET['updateid'];
$sql = "select * from `department` where dNO = $NO";
$result = mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);
$deptNO = $row['dNO'];
$deptName = $row['dName'];
$deptEmps = $row['dEmps'];

if(isset($_POST['submit'])){
    $deptNO = $_POST['dNO'];
    $deptName = $_POST['dName'];
    $deptEmps = $_POST['dEmps'];

    $sql = "update `department` set dNO = $deptNO, dName = '$deptName', dEmps = '$deptEmps' where dNO = $deptNO";
    $result = mysqli_query($con,$sql);
    if($result){
        // echo "Data updated";
        header('location:deptDisplay.php');
    }else{
        die(mysqli_error($con));
    }
}
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.rtl.min.css" >
    <link rel="stylesheet" href="user_styles.css" >
    <title>Update Department</title>
  </head>
  <body>
    
    <div class="container my-5">
    <button class = "btn btn-primary my-5"><a href="deptDisplay.php" class = "text-light">Cancel</a>
    </button>

    <form method = "post">
    <div class="mb-3">
    <label>Department NO.</label>
    <input type="number" class="form-control" placeholder = "Enter Department No." name = "dNO" autocomplete = "off" value = <?php echo $deptNO;?>>
  </div>
  <div class="mb-3">
    <label>Department Name</label>
    <input type="text" class="form-control" placeholder = "Enter Department Name" name = "dName" autocomplete = "off" value = <?php echo $deptName;?>>
  </div>
  <div class="mb-3">
    <label>Number of Employee</label>
    <input type="number" class="form-control" placeholder = "Enter Employees" name = "dEmps" autocomplete = "off" value = <?php echo $deptEmps;?>>
  </div>
  
  <button type="submit" class="btn btn-primary" name = "submit">Update</button>
</form>

    </div>

  </body>
</html>
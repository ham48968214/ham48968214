<?php
include 'connect.php';
if(isset($_POST['submit'])){
    $deptNO = $_POST['dNO'];
    $deptName = $_POST['dName'];
    $deptEmps = $_POST['dEmps'];
    $empCount = "select count(eID) from employee where eDept = $deptNO";

    $sql = "insert into `department` (dNO,dName,dEmps) values ('$deptNO','$deptName','$empCount')";
    $result = mysqli_query($con,$sql);
    if($result){
        //echo "Data inserted";
        header('location:deptDisplay.php');
    }else{
        die(mysqli_error($con));
    }
}
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.rtl.min.css" >
    <link rel="stylesheet" href="user_styles.css" >
    <title>Add Department</title>
  </head>
  <body>
    
    <div class="container my-5">
    <button class = "btn btn-primary my-5"><a href="deptDisplay.php" class = "text-light">Cancel</a>
    </button>

    <form method = "post">
  <div class="mb-3">
    <label>Department NO.</label>
    <input type="number" class="form-control" placeholder = "Enter Department No." name = "dNO" autocomplete = "off">
  </div>
  <div class="mb-3">
    <label>Department Name</label>
    <input type="text" class="form-control" placeholder = "Enter Department Name" name = "dName" autocomplete = "off">
  </div>
  <!-- <div class="mb-3">
    <label>Number of employees</label>
    <input type="number" class="form-control" placeholder = "Enter Employees" name = "dEmps" autocomplete = "off">
  </div> -->
 
  <button type="submit" class="btn btn-primary" name = "submit">Submit</button>
</form>

    </div>

  </body>
</html>